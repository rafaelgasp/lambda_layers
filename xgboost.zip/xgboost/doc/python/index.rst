######################
XGBoost Python Package
######################
This page contains links to all the python related documents on python package.
To install the package package, checkout :doc:`Installation Guide </build>`.

********
Contents
********

.. toctree::
  python_intro
  python_api
  Python examples <https://github.com/dmlc/xgboost/tree/master/demo/guide-python>
