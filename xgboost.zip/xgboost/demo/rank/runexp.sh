#!/bin/bash

../../xgboost mq2008.conf

../../xgboost mq2008.conf task=pred model_in=0004.model
