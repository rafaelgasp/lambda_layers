# Import necessary to preserve backward compatibliity of pickles

from joblib.numpy_pickle import *
